﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.DataProcessor.ExportDto
{
    public class ExportBooksDto
    {
        public string BookName { get; set; }

        public string BookPrice { get; set; }
    }
}
