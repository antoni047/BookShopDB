﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.DataProcessor.ImportDto
{
    public class ImportBookIdsDto
    {
        public int Id { get; set; }
    }
}
