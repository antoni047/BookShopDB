﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-E6O5I68\SQLEXPRESS01;Database=BookShop;Trusted_Connection=True";
    }
}